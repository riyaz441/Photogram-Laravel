        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Admin</div>
                        <a class="nav-link active" href="/admindashboardview">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-gauge"></i></div>
                            Admin Dashboard
                        </a>
                        <a class="nav-link" href="/adminfeedback">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-comments"></i></div>
                            Feedback Management
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>
                    ADMIN
                </div>
            </nav>
        </div>
<?php /**PATH D:\Photogram Project\photogram\resources\views/layouts/includes/sidenavbar.blade.php ENDPATH**/ ?>