$(document).ready(function(){
    $('#download').click(function(){
        $('#pdf').printThis();
    });
});